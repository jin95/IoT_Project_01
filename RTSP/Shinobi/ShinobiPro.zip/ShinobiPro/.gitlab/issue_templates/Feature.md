Feature Request
===============
Summary
-------
[//]: # (Please write a concise description of the feature you would like implemented.)

Prerequisites
-------------
[//]: # (Include links to other feature requests or problems that would need to be handled before implementing this.)

Proposed Implementation
-----------------------
[//]: # (If you have an idea of how the feature should be implemented please write it down here.)

References
----------
[//]: # (Please provide links to projects which implement something similar, or projects that could be used to implement this feature.)

/label ~feature

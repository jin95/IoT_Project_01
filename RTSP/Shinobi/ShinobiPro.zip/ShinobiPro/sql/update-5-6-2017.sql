USE `ccio`;

ALTER TABLE Monitors MODIFY COLUMN `mode` varchar(15);
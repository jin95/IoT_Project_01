sudo apt-get -y install cuda-toolkit-9-1
nvidia-smi
**Detailed Instructions for multiple Operating Systems can now be found in the docs.**

https://shinobi.video/docs/start